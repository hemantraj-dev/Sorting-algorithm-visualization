# Sorting Algorithm Visualizer

An interactive, single-file web app that animates how popular sorting algorithms work, step by step. No libraries, no build step: just open `index.html`.

## Features

- All 7 algorithms (**Bubble, Selection, Insertion, Merge, Quick, Heap, Shell**) race side by side on the same array
- Each panel shows its own pseudocode and complexity
- Adjustable array size (10-100) and animation speed
- Start all / Pause / Resume and a "New array" button
- Live counters for comparisons and writes/swaps
- Color legend: unsorted, comparing, writing/swapping, sorted
- Responsive, with automatic light and dark mode

## Run locally

Download or clone the repo and open `index.html` in any modern browser.

## Deploy on GitHub Pages

1. Create a new repository on GitHub (for example `sorting-visualizer`).
2. Upload `index.html` and `README.md` to the root of the repo.
3. Go to **Settings -> Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then **Save**.
5. After a minute your site is live at `https://<your-username>.github.io/sorting-visualizer/`.

## Complexity

| Algorithm | Best | Average | Worst | Space | Stable |
|-----------|------|---------|-------|-------|--------|
| Bubble    | O(n) | O(n^2) | O(n^2) | O(1) | Yes |
| Selection | O(n^2) | O(n^2) | O(n^2) | O(1) | No |
| Insertion | O(n) | O(n^2) | O(n^2) | O(1) | Yes |
| Merge     | O(n log n) | O(n log n) | O(n log n) | O(n) | Yes |
| Quick     | O(n log n) | O(n log n) | O(n^2) | O(log n) | No |
| Heap      | O(n log n) | O(n log n) | O(n log n) | O(1) | No |
| Shell     | O(n log n) | varies | O(n^2) | O(1) | No |

## How it works

Each algorithm is written as a JavaScript generator that `yield`s after every comparison or swap. The UI advances the generator on a timer and redraws the bars on a `<canvas>`, which makes pausing and speed control simple.

## License

MIT - free to use and modify.
